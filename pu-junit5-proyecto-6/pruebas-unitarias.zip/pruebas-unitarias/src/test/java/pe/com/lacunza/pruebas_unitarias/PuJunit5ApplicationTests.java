package pe.com.lacunza.pruebas_unitarias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PuJunit5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
