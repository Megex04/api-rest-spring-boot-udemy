package pe.com.lacunza.pruebas_unitarias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PuJunit5Application {

	public static void main(String[] args) {
		SpringApplication.run(PuJunit5Application.class, args);
	}

}
