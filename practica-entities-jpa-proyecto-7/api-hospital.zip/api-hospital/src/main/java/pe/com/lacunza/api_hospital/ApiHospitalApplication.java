package pe.com.lacunza.api_hospital;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiHospitalApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiHospitalApplication.class, args);
	}

}
